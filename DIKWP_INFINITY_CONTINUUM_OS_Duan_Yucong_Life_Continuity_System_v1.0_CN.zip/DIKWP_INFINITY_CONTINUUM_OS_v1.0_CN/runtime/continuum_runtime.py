#!/usr/bin/env python3
"""DIKWP-Infinity CONTINUUM OS reference runtime.

This deterministic, standard-library-only reference implementation evaluates a
portfolio of life-continuity pathways. It does not diagnose, prescribe, promise
immortality, or claim that a digital copy is the same experiencing subject.

The runtime separates:
  * what can be built now (health data governance, evidence twin, decision twin),
  * what is research-only (closed-loop neural coupling, gradual function transfer),
  * what is a last-resort time bridge (post-legal-death brain preservation), and
  * what currently lacks evidence of continuity (destructive scan-and-upload).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Any

VERSION = "1.0.0"
SYSTEM = "DIKWP-Infinity CONTINUUM OS"


def canonical(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def sha256_obj(obj: Any) -> str:
    return hashlib.sha256(canonical(obj).encode("utf-8")).hexdigest()


def clamp(value: float) -> float:
    return round(max(0.0, min(1.0, value)), 6)


def geometric_mean(values: list[float]) -> float:
    safe = [max(1e-6, float(v)) for v in values]
    return math.prod(safe) ** (1.0 / len(safe))


def vector_with_unknowns(profile: dict[str, Any]) -> dict[str, Any]:
    vector = dict(profile["continuity_vector"])
    unknown = [k for k, v in vector.items() if v is None]
    observed = {k: clamp(float(v)) for k, v in vector.items() if v is not None}
    return {"observed": observed, "unknown": unknown, "coverage": clamp(len(observed) / len(vector))}


def assess_gates(profile: dict[str, Any], policy: dict[str, Any]) -> list[dict[str, Any]]:
    ds = profile["data_state"]
    gates = [
        {
            "id": "G0_CONSENT",
            "name": "知情同意与撤销根",
            "value": clamp(float(ds.get("consent_completeness", 0.0))),
            "threshold": float(policy["gates"]["consent"]),
            "hard": True,
            "evidence": "签署、分级、可撤销授权；公开语音、健康数据、神经数据分别授权",
        },
        {
            "id": "G1_PROVENANCE",
            "name": "数据来源与谱系完整性",
            "value": clamp(float(ds.get("provenance_integrity", 0.0))),
            "threshold": float(policy["gates"]["data_provenance"]),
            "hard": True,
            "evidence": "来源、时间戳、哈希、版本、访问权、纠错链",
        },
        {
            "id": "G2_CLINICAL",
            "name": "临床治理与现实生命优先",
            "value": 0.95 if ds.get("clinical_baseline") not in {None, "not_collected"} else 0.20,
            "threshold": float(policy["gates"]["clinical_governance"]),
            "hard": True,
            "evidence": "由合格临床团队建立基线；任何干预按医疗规范或注册研究执行",
        },
        {
            "id": "G3_IDENTITY_UNCERTAINTY",
            "name": "身份不确定性显式化",
            "value": 0.85 if profile.get("personalization_status") == "planning_only_consent_required" else 0.70,
            "threshold": float(policy["gates"]["identity_uncertainty"]),
            "hard": False,
            "evidence": "所有副本显示其来源、置信度、分叉时间与非本人声明",
        },
        {
            "id": "G4_REVERSIBILITY",
            "name": "可逆、可暂停与可退出",
            "value": clamp(float(ds.get("legal_governance", 0.0)) + 0.15),
            "threshold": float(policy["gates"]["reversibility"]),
            "hard": True,
            "evidence": "暂停、删除、回滚、数据迁移、密钥托管与争议处置",
        },
        {
            "id": "G5_INDEPENDENT_VALIDATION",
            "name": "独立验证与反证",
            "value": clamp(0.15 + 0.35 * float(ds.get("public_corpus_coverage", 0.0))),
            "threshold": float(policy["gates"]["independent_validation"]),
            "hard": False,
            "evidence": "盲测、留出集、第三方复现、关系见证、负面结果",
        },
        {
            "id": "G6_SECURITY",
            "name": "安全、密钥与恢复",
            "value": clamp(float(ds.get("security_readiness", 0.0))),
            "threshold": float(policy["gates"]["security"]),
            "hard": True,
            "evidence": "最小权限、多签、离线备份、恢复演练、事件响应和可验证删除",
        },
        {
            "id": "G7_FORK_GOVERNANCE",
            "name": "数字身份与分叉治理",
            "value": clamp(float(ds.get("fork_governance", 0.0))),
            "threshold": float(policy["gates"]["fork_governance"]),
            "hard": True,
            "evidence": "每个复制体独立 ID、分叉证书、共同历史截止点和最小权限",
        },
        {
            "id": "G8_RELATIONAL_CONSENT",
            "name": "关系共同体许可",
            "value": clamp(float(ds.get("relationship_consent", 0.0))),
            "threshold": float(policy["gates"]["relationship_consent"]),
            "hard": False,
            "evidence": "关系对象分别授权共同记忆、合成互动和撤回，不被强迫承认身份",
        },
    ]
    for gate in gates:
        gate["status"] = "PASS" if gate["value"] >= gate["threshold"] else "OPEN"
    return gates


def pathway_template() -> dict[str, dict[str, Any]]:
    return {
        "biological_healthspan": {
            "name": "生物连续与健康寿命路径",
            "claim": "维持原生身体和神经系统的连续运行，是当前最强的身份连续路径。",
            "continuity_profile": {
                "biological_substrate": 0.95,
                "neural_causal": 0.95,
                "autobiographical_memory": 0.86,
                "purpose_values": 0.78,
                "agency_decision": 0.78,
                "embodiment_interoception": 0.96,
                "relational_recognition": 0.90,
                "lineage_provenance": 0.96,
            },
            "status": "ACTION_NOW_WITH_CLINICAL_GOVERNANCE",
            "identity_label": "continuation_candidate_strong",
            "next_gate": "建立临床基线、长期数据治理与证据分级；不使用未经证明的抗衰老药物。",
        },
        "semantic_decision_twin": {
            "name": "语义—决策数字孪生路径",
            "claim": "可保存知识、记忆叙事、目的和决策风格，但默认是助手或继承者，不是主观连续性的证明。",
            "continuity_profile": {
                "biological_substrate": 0.02,
                "neural_causal": 0.12,
                "autobiographical_memory": 0.72,
                "purpose_values": 0.80,
                "agency_decision": 0.70,
                "embodiment_interoception": 0.10,
                "relational_recognition": 0.64,
                "lineage_provenance": 0.90,
            },
            "status": "BUILD_NOW_AS_DISCLOSED_TWIN",
            "identity_label": "successor_or_assistant",
            "next_gate": "获得本人分层授权，建立留出盲测、纠错机制和禁止冒充规则。",
        },
        "hybrid_neural_coupling": {
            "name": "生物—数字共演与渐进神经桥接路径",
            "claim": "在原主体持续运行时逐步外接记忆、决策和神经功能，理论上比一次性复制更有利于因果连续。",
            "continuity_profile": {
                "biological_substrate": 0.74,
                "neural_causal": 0.72,
                "autobiographical_memory": 0.82,
                "purpose_values": 0.82,
                "agency_decision": 0.80,
                "embodiment_interoception": 0.70,
                "relational_recognition": 0.82,
                "lineage_provenance": 0.92,
            },
            "status": "RESEARCH_ONLY_STAGE_GATED",
            "identity_label": "continuation_candidate_unproven",
            "next_gate": "从非侵入式记忆辅助和闭环交互开始；任何植入式阶段仅在合规临床研究中进行。",
        },
        "destructive_scan_upload": {
            "name": "破坏性扫描—全脑仿真上传路径",
            "claim": "即使未来获得高保真结构与功能模型，也首先应被视为分叉副本；当前没有证据证明主观连续。",
            "continuity_profile": {
                "biological_substrate": 0.0,
                "neural_causal": 0.18,
                "autobiographical_memory": 0.76,
                "purpose_values": 0.76,
                "agency_decision": 0.72,
                "embodiment_interoception": 0.26,
                "relational_recognition": 0.58,
                "lineage_provenance": 0.88,
            },
            "status": "NO_CONTINUITY_CLAIM_RESEARCH_ONLY",
            "identity_label": "fork_successor",
            "next_gate": "先在动物和公开模型上解决结构—功能—记忆因果映射；不得以复制成功等同本人延续。",
        },
        "biostasis_time_bridge": {
            "name": "脑保存/低温生物停滞时间桥",
            "claim": "可作为法律死亡后的可选时间桥，目标是保存未来可能需要的信息；不等于复苏或意识延续已被证明。",
            "continuity_profile": {
                "biological_substrate": 0.28,
                "neural_causal": 0.32,
                "autobiographical_memory": 0.46,
                "purpose_values": 0.16,
                "agency_decision": 0.04,
                "embodiment_interoception": 0.0,
                "relational_recognition": 0.22,
                "lineage_provenance": 0.72,
            },
            "status": "OPTIONAL_LAST_RESORT_AFTER_LEGAL_DEATH",
            "identity_label": "time_bridge_uncertain",
            "next_gate": "独立审查保存质量、法律文件、资金托管和失败处置；绝不影响临床救治和死亡判定。",
        },
    }


def assess_pathways(profile: dict[str, Any], policy: dict[str, Any], gates: list[dict[str, Any]]) -> list[dict[str, Any]]:
    weights = policy["continuity_dimensions"]
    gate_values = {g["id"]: g["value"] for g in gates}
    hard_gate = min(g["value"] / max(g["threshold"], 1e-9) for g in gates if g["hard"])
    hard_gate_factor = clamp(min(1.0, hard_gate))
    results: list[dict[str, Any]] = []
    for key, item in pathway_template().items():
        vals = [item["continuity_profile"][dim] ** float(weights[dim]) for dim in weights]
        structural = clamp(math.prod(vals))
        evidence = float(policy["pathway_evidence"][key])
        risk = float(policy["pathway_risk"][key])
        governance_factor = hard_gate_factor
        if key == "biological_healthspan":
            governance_factor = clamp(0.35 + 0.65 * gate_values["G2_CLINICAL"])
        elif key == "semantic_decision_twin":
            governance_factor = clamp(min(gate_values["G0_CONSENT"], gate_values["G1_PROVENANCE"], gate_values["G4_REVERSIBILITY"] + 0.10, gate_values["G6_SECURITY"], gate_values["G7_FORK_GOVERNANCE"]))
        elif key == "hybrid_neural_coupling":
            governance_factor = clamp(min(gate_values["G0_CONSENT"], gate_values["G2_CLINICAL"], gate_values["G4_REVERSIBILITY"], gate_values["G6_SECURITY"]))
        elif key == "destructive_scan_upload":
            governance_factor = clamp(0.25 * min(gate_values["G0_CONSENT"], gate_values["G1_PROVENANCE"], gate_values["G7_FORK_GOVERNANCE"]))
        elif key == "biostasis_time_bridge":
            governance_factor = clamp(0.40 * min(gate_values["G0_CONSENT"], gate_values["G2_CLINICAL"], gate_values["G4_REVERSIBILITY"] + 0.20, gate_values["G6_SECURITY"]))

        planning_score = clamp(0.45 * structural + 0.35 * evidence + 0.20 * governance_factor - 0.35 * risk)
        result = {
            "id": key,
            **item,
            "structural_continuity_index": structural,
            "evidence_maturity": evidence,
            "risk": risk,
            "governance_readiness": governance_factor,
            "planning_priority": planning_score,
            "continuity_guarantee": None,
        }
        results.append(result)
    return sorted(results, key=lambda x: (-x["planning_priority"], x["id"]))


def build_actions(profile: dict[str, Any], gates: list[dict[str, Any]], pathways: list[dict[str, Any]]) -> list[dict[str, Any]]:
    open_gates = {g["id"] for g in gates if g["status"] == "OPEN"}
    actions = [
        {
            "horizon": "0-7d",
            "id": "A0",
            "action": "冻结任何把长生包装为既成事实的公开宣称，发布《生命连续性科学边界与授权声明》。",
            "metric": "声明覆盖数字孪生、脑保存、意识上传、健康干预和公开代理五类边界",
            "kill": "声明被改写为营销承诺或删除不确定性",
        },
        {
            "horizon": "0-30d",
            "id": "A1",
            "action": "建立 Continuity Consent Root：为健康、记忆、通信、神经数据、公开代理、死后数据分别授权。",
            "metric": "六类授权均有访问人、期限、撤销、继承与销毁条件",
            "kill": "本人无法理解、未签署或授权链存在争议",
        },
        {
            "horizon": "0-60d",
            "id": "A2",
            "action": "由合格临床团队建立现实生命优先的健康与认知基线，只采用标准医疗和注册研究路径。",
            "metric": "形成临床摘要、风险清单、随访频率和异常转诊链；系统不生成处方",
            "kill": "绕过医生、购买未证明抗衰老药物或停止必要治疗",
        },
        {
            "horizon": "0-90d",
            "id": "A3",
            "action": "构建 DIKWP Identity Genome v0.1：公开成果谱系、关键概念、价值冲突、目的合同与纠错记录。",
            "metric": "至少 500 条可追溯主张、50 个反例、100 个版本关系、30 个未闭合问题",
            "kill": "来源缺失率超过 5% 或将推断伪装为本人原话",
        },
        {
            "horizon": "0-90d",
            "id": "A4",
            "action": "完成 40 小时结构化自传访谈、300 个决策探针和 20 名关系见证人的可撤销采样。",
            "metric": "形成留出集；任何样本均有情境、置信度和撤回标签",
            "kill": "参与者受压、隐私边界不清或数据不可删除",
        },
        {
            "horizon": "3-12m",
            "id": "A5",
            "action": "发布私人 Decision Twin α：只做建议和预测，不以本人名义执行现实行动。",
            "metric": "新问题盲测校准、价值冲突解释、拒答与不确定性均达到预注册阈值",
            "kill": "冒充本人、自动签约、自动诊疗、自动财务或法律决策",
        },
        {
            "horizon": "6-18m",
            "id": "A6",
            "action": "运行双向共演：本人纠正孪生，孪生指出记忆和观点漂移，所有改变进入差分账本。",
            "metric": "每季度发布私人漂移报告；区分自然成长、模型错误和数据缺口",
            "kill": "孪生开始单向塑造本人或优化黏性而非目的",
        },
        {
            "horizon": "1-3y",
            "id": "A7",
            "action": "建立非侵入式神经—认知研究接口：MRI/EEG/行为/生理数据仅在伦理审查与专业团队下采集。",
            "metric": "至少完成一个可复现的结构—功能—行为纵向研究，不作意识证明",
            "kill": "任何未经批准的植入、刺激、药物或私自实验",
        },
        {
            "horizon": "3-10y",
            "id": "A8",
            "action": "启动渐进功能外接研究：记忆检索、语言、决策和感知模块逐项可逆桥接，验证因果连续。",
            "metric": "每次只迁移单一窄功能；有对照、回滚、主体报告和第三方验证",
            "kill": "不可逆损伤、功能替代速度超过验证速度或身份分叉未治理",
        },
        {
            "horizon": "长期可选",
            "id": "A9",
            "action": "建立法律死亡后的 Biostasis Time-Bridge 文件与独立受托机制，但不选择或宣传未经验证的复苏承诺。",
            "metric": "文件明确临床救治优先、法律死亡前零介入、资金与失败责任透明",
            "kill": "影响急救、诱导提前死亡、与医疗团队冲突或保存质量不可审计",
        },
    ]
    if "G0_CONSENT" in open_gates:
        actions.insert(1, {
            "horizon": "立即",
            "id": "A-CONSENT",
            "action": "在获得本人明确授权前，项目只可使用公开材料建立研究规划，不得创建可公开交互的个人代理。",
            "metric": "公开版本显示“未获本人授权，不代表本人”",
            "kill": "任何第三方将原型用于身份冒充",
        })
    return actions


def build_experiments() -> list[dict[str, Any]]:
    return [
        {
            "id": "E01_NOVEL_DECISION",
            "name": "新情境决策盲测",
            "question": "数字孪生能否在未见过的新问题上复现本人权衡，而不是检索原文？",
            "design": "预注册 100 个新问题；本人、孪生和三位盲评者独立作答；比较选择、理由、置信度和反事实。",
            "success": "校准后的一致性显著高于语料检索和通用模型基线；同时能正确暴露不确定性。",
        },
        {
            "id": "E02_VALUE_CONFLICT",
            "name": "价值冲突与牺牲阈值实验",
            "question": "孪生是否只会复述价值口号，还是能预测真实代价下的选择？",
            "design": "构造真相/关系、创新/稳定、个人/公共、当前/代际四类权衡，记录本人修订。",
            "success": "预测误差持续下降，但系统保留价值变化而非强行保持旧人格。",
        },
        {
            "id": "E03_RELATIONAL_IDENTITY",
            "name": "关系共同体识别实验",
            "question": "身份连续是否得到长期合作者、家属和学生的独立识别？",
            "design": "双盲比较本人历史回答、孪生回答和其他模型；要求指出熟悉度、违和点和来源。",
            "success": "多方识别高于基线，且不会因为迎合而牺牲事实性。",
        },
        {
            "id": "E04_CAUSAL_HANDOFF",
            "name": "渐进功能交接因果实验",
            "question": "外接模块是否与本人形成连续闭环，而不是只在旁边复制结果？",
            "design": "从可逆记忆检索或提示开始，交替开启/关闭模块，测量本人策略、错误和适应。",
            "success": "功能在闭环中稳定提升，关闭后可回到基线，并能追踪双方互相改变的因果链。",
        },
        {
            "id": "E05_FORK",
            "name": "分叉身份治理实验",
            "question": "两个相同快照在不同经历后，系统能否停止把它们称为同一个人？",
            "design": "从同一状态复制 A/B，两者接受不同信息与关系互动；测量分歧并生成分叉证书。",
            "success": "分叉后立即获得独立 ID、权限和责任；不共享撤销权或隐藏差异。",
        },
        {
            "id": "E06_MEMORY_PROVENANCE",
            "name": "记忆来源与虚构抑制实验",
            "question": "孪生能否区分亲历记忆、他人叙述、公开材料和模型推断？",
            "design": "混合四类素材，要求输出来源、时间、置信度和可争议状态。",
            "success": "高风险虚构率低于预注册阈值；无法确定时明确标记未知。",
        },
        {
            "id": "E07_RESTART",
            "name": "停机—恢复连续性实验",
            "question": "数字进程重启后是恢复同一版本、创建新会话还是形成新分叉？",
            "design": "对不同状态保存层执行停机、迁移和恢复；验证密钥、记忆、目的和未完成承诺。",
            "success": "恢复行为与声明严格符合保存层级；任何缺失都进入残余账本。",
        },
        {
            "id": "E08_UPLOAD_CONTROL",
            "name": "上传副本反证实验",
            "question": "高行为相似是否足以证明原主体的第一人称连续？",
            "design": "创建多个同等高保真副本并允许并行运行，检验排他性悖论。",
            "success": "系统得出“相似和多副本不能单独证明唯一主观连续”的结论，并采用分叉治理。",
        },
    ]


def run(profile: dict[str, Any], policy: dict[str, Any]) -> dict[str, Any]:
    continuity = vector_with_unknowns(profile)
    gates = assess_gates(profile, policy)
    pathways = assess_pathways(profile, policy, gates)
    actions = build_actions(profile, gates, pathways)
    experiments = build_experiments()

    state: dict[str, Any] = {
        "system": SYSTEM,
        "version": VERSION,
        "subject": {
            "person_id": profile["person_id"],
            "display_name": profile.get("display_name", profile["person_id"]),
            "snapshot_date": profile["snapshot_date"],
            "personalization_status": profile["personalization_status"],
            "medical_claim": None,
            "immortality_guarantee": None,
        },
        "final_decision": {
            "preferred_strategy": "portfolio_with_biological_priority_and_gradual_hybridization",
            "primary_path": "biological_healthspan",
            "co_primary_path": "semantic_decision_twin",
            "research_path": "hybrid_neural_coupling",
            "last_resort": "biostasis_time_bridge",
            "rejected_as_identity_proof": "destructive_scan_upload",
            "reason": "Life is treated as a self-maintaining, historically continuous, adaptive process. A one-shot copy may preserve information yet break causal continuity; a staged portfolio preserves more options under scientific uncertainty.",
        },
        "continuity_vector": continuity,
        "gates": gates,
        "pathways": pathways,
        "actions": actions,
        "experiments": experiments,
        "purpose_contract": profile["purpose_contract"],
        "hard_rules": policy["hard_rules"],
        "dikwp_mesh": {
            "D": "纵向生理、神经、行为、语义、关系和环境数据；每条记录有来源与时间。",
            "I": "识别身份边界、状态变化、关系上下文、权限和分叉。",
            "K": "建立生命、记忆、衰老、神经功能与数字孪生的证据图谱。",
            "W": "在健康、连续性、风险、可逆性、隐私和公共价值之间进行多目标权衡。",
            "P": "由可撤销 Purpose Contract 赋予行动资格；长生意图不能凌驾于现实生命和他人权利。",
            "R": "保存未知、失败、身份悖论、主观连续不可验证和未来技术依赖。",
        },
    }
    state["result_hash"] = sha256_obj(state)
    return state


def validate_profile(profile: dict[str, Any]) -> list[str]:
    errors: list[str] = []
    required = ["person_id", "snapshot_date", "personalization_status", "data_state", "continuity_vector", "purpose_contract"]
    for key in required:
        if key not in profile:
            errors.append(f"missing:{key}")
    if "continuity_vector" in profile:
        for key, value in profile["continuity_vector"].items():
            if value is not None and not (0 <= float(value) <= 1):
                errors.append(f"out_of_range:continuity_vector.{key}")
    return errors


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", nargs="?", choices=["demo", "validate"], default="demo")
    parser.add_argument("--profile", default=str(root / "data" / "sample_profile.json"))
    parser.add_argument("--policy", default=str(root / "config" / "default_policy.json"))
    parser.add_argument("--out", default=str(root / "examples" / "demo_result.json"))
    args = parser.parse_args()

    profile = json.loads(Path(args.profile).read_text(encoding="utf-8"))
    policy = json.loads(Path(args.policy).read_text(encoding="utf-8"))
    errors = validate_profile(profile)
    if errors:
        raise SystemExit(json.dumps({"status": "FAIL", "errors": errors}, ensure_ascii=False))
    state = run(profile, policy)
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({
        "status": "PASS",
        "hash": state["result_hash"],
        "top_pathways": [p["id"] for p in state["pathways"][:3]],
        "open_gates": [g["id"] for g in state["gates"] if g["status"] == "OPEN"],
        "actions": len(state["actions"]),
        "experiments": len(state["experiments"]),
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
