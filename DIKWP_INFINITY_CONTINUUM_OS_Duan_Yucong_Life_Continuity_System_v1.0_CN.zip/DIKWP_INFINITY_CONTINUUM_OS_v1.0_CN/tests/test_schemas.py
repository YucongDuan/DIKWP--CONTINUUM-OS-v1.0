#!/usr/bin/env python3
from __future__ import annotations
import json
import unittest
from pathlib import Path
from jsonschema import Draft202012Validator

ROOT = Path(__file__).resolve().parents[1]

CASES = [
    ("consent_root.schema.json", "consent_root.example.json"),
    ("fork_certificate.schema.json", "fork_certificate.example.json"),
    ("purpose_contract.schema.json", "purpose_contract.example.json"),
]

class SchemaTests(unittest.TestCase):
    def test_schema_examples(self) -> None:
        for schema_name, example_name in CASES:
            with self.subTest(schema=schema_name):
                schema = json.loads((ROOT / "schemas" / schema_name).read_text(encoding="utf-8"))
                instance = json.loads((ROOT / "examples" / example_name).read_text(encoding="utf-8"))
                Draft202012Validator.check_schema(schema)
                errors = sorted(Draft202012Validator(schema).iter_errors(instance), key=lambda e: list(e.path))
                self.assertEqual(errors, [], [e.message for e in errors])

    def test_all_schemas_are_valid(self) -> None:
        for path in sorted((ROOT / "schemas").glob("*.schema.json")):
            with self.subTest(path=path.name):
                Draft202012Validator.check_schema(json.loads(path.read_text(encoding="utf-8")))

if __name__ == "__main__":
    unittest.main()
