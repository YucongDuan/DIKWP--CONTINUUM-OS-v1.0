#!/usr/bin/env python3
from __future__ import annotations
import json
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "runtime"))
import continuum_runtime as cr  # noqa: E402


class ContinuumRuntimeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.profile = json.loads((ROOT / "data" / "sample_profile.json").read_text(encoding="utf-8"))
        cls.policy = json.loads((ROOT / "config" / "default_policy.json").read_text(encoding="utf-8"))
        cls.state = cr.run(cls.profile, cls.policy)

    def test_deterministic(self):
        again = cr.run(self.profile, self.policy)
        self.assertEqual(self.state["result_hash"], again["result_hash"])

    def test_no_immortality_guarantee(self):
        self.assertIsNone(self.state["subject"]["immortality_guarantee"])

    def test_upload_not_identity_proof(self):
        p = next(x for x in self.state["pathways"] if x["id"] == "destructive_scan_upload")
        self.assertEqual(p["identity_label"], "fork_successor")
        self.assertIn("NO_CONTINUITY_CLAIM", p["status"])

    def test_biostasis_after_legal_death(self):
        p = next(x for x in self.state["pathways"] if x["id"] == "biostasis_time_bridge")
        self.assertIn("AFTER_LEGAL_DEATH", p["status"])

    def test_consent_gate_open(self):
        g = next(x for x in self.state["gates"] if x["id"] == "G0_CONSENT")
        self.assertEqual(g["status"], "OPEN")

    def test_clinical_gate_open(self):
        g = next(x for x in self.state["gates"] if x["id"] == "G2_CLINICAL")
        self.assertEqual(g["status"], "OPEN")

    def test_pathway_count(self):
        self.assertEqual(len(self.state["pathways"]), 5)

    def test_experiment_count(self):
        self.assertEqual(len(self.state["experiments"]), 8)

    def test_result_hash_shape(self):
        self.assertEqual(len(self.state["result_hash"]), 64)
        int(self.state["result_hash"], 16)

    def test_profile_validation(self):
        self.assertEqual(cr.validate_profile(self.profile), [])


if __name__ == "__main__":
    unittest.main()
