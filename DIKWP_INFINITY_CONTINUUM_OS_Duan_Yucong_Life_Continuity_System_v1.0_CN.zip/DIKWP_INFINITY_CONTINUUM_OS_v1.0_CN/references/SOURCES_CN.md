# 主要来源与证据边界

1. Kofman K. 等，Defining Life: A Conversation, Organisms, 2026。用于生命多维形态空间、约束闭包、身份随部件变化而维持、规则元动力和观察者关系的理论依据。
2. U.S. FDA, Medication Health Fraud for Specific Diseases and Conditions, 2026。当前没有药物被证明可以减慢或逆转衰老。
3. U.S. National Institute on Aging, Interventions Testing Program。该项目检验小鼠寿命与健康寿命干预，不能直接外推为人类处方。
4. Nature, MICrONS Functional Connectomics, 2025。约 75,000 个神经元的功能成像与超过 200,000 个细胞、5 亿突触的电镜重建共同注册。
5. NIH Research Matters, Unseen details of human brain structure revealed, 2024。1 立方毫米人类皮层产生约 1.4 PB 数据，包含约 57,000 个细胞和约 1.5 亿突触。
6. NIH Research Matters, Brain-computer interface restores natural speech after paralysis, 2025。说明闭环神经接口可恢复部分交流功能，但不等于意识上传。
7. NIH Research Matters, Decoding inner speech from brain signals, 2025。说明内言语解码可行，同时必须把精神隐私和解锁机制内置。
8. PNAS, Functional recovery of the adult murine hippocampus after cryopreservation by vitrification, 2026。证明小鼠海马短期功能恢复的进展，但不是人类复苏证据。
9. National Academies, Foundational Research Gaps and Future Directions for Digital Twins, 2023。数字孪生应动态更新、具预测能力、与物理对象双向交互，并实施验证、确认和不确定性量化。
10. 第四届世界人工意识大会未来发展预测与判断报告，2026。强调公共产品应可引用、可复现、可执行、可持续迭代，并明确不把当前 AI 主观体验作为既定事实。
