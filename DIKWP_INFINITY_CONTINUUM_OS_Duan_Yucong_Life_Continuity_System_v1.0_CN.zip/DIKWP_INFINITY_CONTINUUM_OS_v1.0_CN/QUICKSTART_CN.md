# 快速启动

## 1. 查看系统

双击或用浏览器打开：

```text
prototype/index.html
```

页面不会联网，可切换“公开材料起点、授权与基线就绪、私有决策孪生、渐进桥接研究”四种场景，并导出当前 JSON 状态。

## 2. 运行参考内核

```bash
python runtime/continuum_runtime.py demo
```

默认读取：

- `data/sample_profile.json`
- `config/default_policy.json`

默认写出：

- `examples/demo_result.json`

输出包括五条路线、门禁、11 项行动、8 项实验和确定性 SHA-256。

## 3. 替换个人配置

复制 `data/sample_profile.json`，只填写已经获得本人明确授权的数据。未知值保持 `null`，不要猜测健康、神经、家庭或私人意愿。

```bash
python runtime/continuum_runtime.py demo \
  --profile data/your_authorized_profile.json \
  --out examples/your_result.json
```

## 4. 验证

```bash
python tests/test_runtime.py -v
python tests/test_schemas.py -v
```

## 5. 发布前硬门禁

- 有签署且可撤销的 Consent Root；
- 数据来源、版本和哈希完整；
- 公开输出显著标注“模型，不是本人”；
- 可暂停、删除、回滚和导出；
- 至少有独立盲测和负面结果；
- 每个复制体获得独立 Fork Certificate；
- 不进行医疗处方、身份冒充、自动法律/财务/医疗行动。
